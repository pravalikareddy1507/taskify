document.addEventListener('DOMContentLoaded', function () {
    const journalEntry = document.getElementById('journal-entry');
    const saveButton = document.getElementById('save-entry');

    saveButton.addEventListener('click', function () {
        const entryText = journalEntry.value;

        // Here, you can implement code to save the journal entry, e.g., to a database.

        // For simplicity, we'll just display an alert.
        if (entryText.trim() !== '') {
            alert('Journal entry saved!');
            journalEntry.value = ''; // Clear the textarea
        } else {
            alert('Please write a journal entry before saving.');
        }
    });
});
