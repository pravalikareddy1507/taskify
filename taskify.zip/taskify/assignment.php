<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="a.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Reminder</title>
</head>
<body>
    <header>
        <h1> Reminder</h1>
    </header>
    <main>
        <section>
            <h2>Create a  Reminder</h2>
            <form method="post" id="assignment-form">
                <label for="title">remainder Title:</label>
                <input type="text" id="title" name="title" required>

                <label for="due_date">Due Date:</label>
                <input type="date" id="due_date" name="due_date" required>

                <label for="due_time">Due Time:</label>
                <input type="time" id="due_time" name="due_time" required>

                <button type="submit" id="b" name="b">Create Reminder</button>
                <audio id="reminder-sound" src="https://bojjlapravalika1507.000webhostapp.com/alarm.mp3" preload="auto"></audio>

            </form>
        </section>
    </main>

    <?php
    if (isset($_POST['b'])) {
        $title = $_POST["title"];
        $due_date = $_POST["due_date"];
        $due_time = $_POST["due_time"];
        
        $conn = new mysqli('localhost', 'root', '', 'taskify');
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        } else {
            $stmt = $conn->prepare("insert into assignment(date,time, title) values(?, ?, ?)");
            $stmt->bind_param("sss", $due_date, $due_time, $title);
            $stmt->execute();
            echo '<script>alert("Added successfully");</script>';
            $stmt->close();
            $conn->close();
        }
    }
    ?>

    <script>
        // JavaScript for scheduling reminders
        document.getElementById('assignment-form').addEventListener('submit', function (event) {
            event.preventDefault();

            const title = document.getElementById('title').value;
            const dueDate = document.getElementById('due_date').value;
            const dueTime = document.getElementById('due_time').value;

            const dueDateTime = new Date(dueDate + ' ' + dueTime).getTime();
            const currentTime = new Date().getTime();

            if (dueDateTime > currentTime) {
                const timeRemaining = dueDateTime - currentTime;
                const hours = Math.floor(timeRemaining / 3600000);
                const minutes = Math.floor((timeRemaining % 3600000) / 60000);

                alert(`Assignment: ${title}\nDue Date and Time: ${dueDate} ${dueTime}\nTime Remaining: ${hours} hours and ${minutes} minutes`);

                setTimeout(function () {
                    
            
                    const audio = document.getElementById('reminder-sound');
        audio.play();
         // Check if the browser supports the Notification API
         if ("Notification" in window) {
                    // Request permission to display notifications
                    Notification.requestPermission().then(function (permission) {
                        if (permission === "granted") {
                            new Notification(`Reminder: It's time to complete the work: ${title}`);
                        }
                    });
                }
        
        
                }, timeRemaining);
                
            } else {
                alert(`Assignment ${title} is already overdue.`);
            }
        });
    </script>
</body>
</html>
