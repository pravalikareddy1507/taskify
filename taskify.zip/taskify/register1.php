<html>
    <head>
        <title>REGISTRATION FORM </title>
        <link rel="stylesheet"  type="text/css" href="style1.css">
    </head>
    <body>
        <div class="registration">
            <form action="#" method="POST">
                <h1 >REGISTRATION FORM </h1>

    <label>username</label>
    <br>
    <input id="u" name="u" type="text" required placeholder="enter username">
    <br>
    <label>password</label>
    <br>
    <input id="p" name="p" type="password"required placeholder="enter password">
    <br>
    <label>gender</label>
    <br>
    <select required  id="gender" name="gender">
    <option >select</option>
    <option >male</option>
    <option >female</option>
    <option >others</option>
    </select>
    <br>
    <label>phonenumber</label>
    <br>
    <input id="n" name="n" type="text" required placeholder="enter phonenumber">
    <br>
    <label>email</label>
    <br>
    <input id="e" name="e" type="mail" required placeholder="enter email">
    <br>
    <label> Education</label>
    <br>
    <select required  id="ed" name="ed" >
        <option >select</option>
        <option >secondary school Education</option>
        <option >graduation</option>
        <option >post-graduation</option>
        <option >others</option>
    </select>
    <br>

    <button class="bu" id="b" name="b" type="submit" >Sign up</button>
    <p>Already you have account?<a href="login1.php">login</a></p>
            </form>
        </div>
<?php
          if(isset($_POST['b']))
    {
            $a=$_POST['u'];
            $b=$_POST['p'];
            $c=$_POST['gender'];
            $d=$_POST['n'];
            $e=$_POST['e'];
            $f=$_POST['ed'];

$conn=new mysqli('localhost','root','','taskify');
if($conn->connect_error){
    die('connection failed:'.$conn->connect_error);
}
else{
    $stmt=$conn->prepare("insert into register (username,password,gender,phonenumber,email,education)values(?,?,?,?,?,?)");
    $stmt->bind_param("ssssss",$a,$b,$c,$d,$e,$f);
    if(!strlen(preg_replace("/[^0-9]/", "", $b)===10))
    {
        echo '<script>alert("enter valid phone number...");</script>';
    }
    else if(!filter_var($e,FILTER_VALIDATE_EMAIL)){
        echo '<script>alert("enter valid email id...");</script>';
    }
    else{
    $stmt->execute();
    echo '<script>alert("registration successfull...");</script>';
    }
    $stmt->close();
    $conn->close();
}
}
?>

</body>
</html>