if(isset(GET['date'])) {
    // Retrieve data from the form
   
}  