<?php
// Database connection code here
$conn = new mysqli('localhost', 'root', '', 'taskify');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the note ID to be deleted
    $note_id = $_POST['note_id'];

    // Create a SQL query to delete the note
    $sql = "DELETE FROM notes WHERE note_id = $note_id";

    if ($conn->query($sql) === TRUE) {
        echo 'Note deleted successfully';
    } else {
        echo 'Error: ' . $sql . '<br>' . $conn->error;
    }
}

$conn->close();
?>
