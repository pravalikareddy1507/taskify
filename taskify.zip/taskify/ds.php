<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="ds.css">
    <title>Diary App</title>
</head>
<body>
    

    <form action="#" method="post" id="diary-entry-form">
        <!-- Your form inputs for adding new entries -->
    </form>
    <?php
    // Database connection code here
    $conn = new mysqli('localhost', 'root', '', 'taskify');

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // Retrieve and display existing entries
    $sql = "SELECT did, date, day, time, title, content FROM diary";
    $result = $conn->query($sql);
    $g='false';

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $did=$row['did'];
            $date = $row['date'];
            $day = $row['day'];
            $time = $row['time'];
            $title = $row['title'];
            $content = $row['content'];

            echo "<div class='entry'>";
            echo "<strong>Date:</strong> $date<br>";
            echo "<strong>Day:</strong> $day<br>";
            echo "<strong>Time:</strong> $time<br>";
            echo "<strong>Title:</strong> $title<br>";
            echo "<p>$content</p>";
            echo "<form action='d.php' method='post'>";
            echo "<input type='hidden' name='did' value='did'>"; 
            echo "<input type='submit' value='Delete'>";
            echo "</form>";
            echo "</div>";
        }
    } else {
        echo "No entries found.";
    }

    $conn->close();
    
           
    
          
    
    ?>
    
    
    
    
</body>
</html>
