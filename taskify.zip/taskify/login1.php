<html>
    <head>
        <title>LOGIN FORM </title>
        <link rel="stylesheet"  type="text/css" href="style1.css">
    </head>
    <body>
        <div class="registration">
            <form action="#" method="POST">
                <h1 >LOGIN FORM </h1>

    <label>username</label>
    <br>
    <input id="u" name="u" type="text" required placeholder="enter username">
    <br>
    <label>password</label>
    <br>
    <input id="p" name="p" type="password"required placeholder="enter password">
    <br>
    <button class="bu" id="b" name="b" type="submit" >Sign in</button>
    <p>Don't have an account yet?<a href="register1.php">Register</a></p>
            </form>
        </div>
        <?php
  
        if (isset($_POST['b'])) {
            $username = $_POST['u'];
            $password = $_POST['p'];
        
            // Sanitize user inputs (not shown in this code; you should validate and sanitize user inputs here)
        
            $conn = new mysqli('localhost', 'root', '', 'taskify');
            if ($conn->connect_error) {
                die('Connection failed: ' . $conn->connect_error);
            } else {
                $stmt = $conn->prepare("SELECT * FROM register WHERE username=?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $stmt_result = $stmt->get_result();
        
                if ($stmt_result->num_rows > 0) {
                    $data = $stmt_result->fetch_assoc();
            
        
                    // Verify the password
                    if ($data['password'] === $password) {
                        echo '<script>alert("login successfull");</script>';
                        // You can now set session variables or redirect the user to a protected area.
                    } else {
                        echo '<script>alert("invalid password");</script>';
                    }
                } else {
                    echo '<script>alert("invalid username");</script>';
                }
                $stmt->close();
                $conn->close();
            }
        }
        ?>
        
        
    </body>
</html>