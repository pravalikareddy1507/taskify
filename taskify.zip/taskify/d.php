<?php
// Database connection code here
$conn = new mysqli('localhost', 'root', '', 'taskify');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the note ID to be deleted
    $did = $_POST['did'];

    // Create a SQL query to delete the note
    $sql = "DELETE FROM diary WHERE did = $did";

    if ($conn->query($sql) === TRUE) {
        echo 'diary deleted successfully';
    } else {
        echo 'Error: ' . $sql . '<br>' . $conn->error;
    }
}

$conn->close();
?>
