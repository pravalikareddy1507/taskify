<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet"  type="text/css" href="d.css">
    <title>Diary App</title>
</head>
<body>
    <h1>My Diary</h1>

    
    <form action="#" method="post" id="diary-entry-form">
        
        <div style="display: flex;">
            <input type="date" id="date" name="date" placeholder="Date" required>
            
          
            <input type="text" id="day" name="day" placeholder="Day" required>
            <input type="time" id="time" name="time" placeholder="Time" required>
          </div>
          
        <input type="text" id="title" name="title" placeholder="Title" required>
        <input type="text" id="content" name="content"placeholder="write your Content here ....." required>
        <div class="button-container" style="display: flex;">
        <button type="submit" id="b" name="b" >Add Entry</button>
       
    </form>
    <div>
        <button type="submit" id="c" name="c" >click here to view saved entry</button>
        <script>document.getElementById("c").addEventListener("click", function() {
    window.location.href = "ds.php";
});
</script>
        </div> 
</div>  

    <?php
if(isset($_POST['b'])) {
    // Retrieve data from the form
    $a = $_POST["date"];
    $b = $_POST["day"];
    $c = $_POST["time"];
    $d = $_POST["title"];
    $e = $_POST["content"];
    
    $conn = new mysqli('localhost', 'root', '', 'taskify');
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    } else {
        $stmt = $conn->prepare("insert into diary(date, day, time, title, content) values(?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $a, $b, $c, $d, $e);
        $stmt->execute();
        echo '<script>alert("Added successfully");</script>';

        $stmt->close();
        $conn->close();
    }
} 
?>

    
    



</body>
</html>
