document.getElementById("diary-entry-form").addEventListener("submit", function (event) {
    event.preventDefault();

    // Get form data
    const date = document.getElementById("date").value;
    const day = document.getElementById("day").value;
    const time = document.getElementById("time").value;
    const title = document.getElementById("title").value;
    const content = document.getElementById("content").value;

    // Create a data object to send to the server
    const data = new FormData();
    data.append("date", date);
    data.append("day", day);
    data.append("time", time);
    data.append("title", title);
    data.append("content", content);

    // Send the data to the server using Fetch API
    fetch("diary.php", {
        method: "POST",
        body: data,
    })
    .then(response => response.text())
    .then(data => {
        // Handle the response from the server (e.g., show a success message)
        console.log(data);
    })
    .catch(error => {
        console.error("Error: " + error);
    });
});
