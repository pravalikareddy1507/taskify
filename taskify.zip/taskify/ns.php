<!DOCTYPE html>
<html lang="en">
<head>
    <title>notes</title>
    <head><link rel="stylesheet"  type="text/css" href="ns.css">
</head>
<body>
<h2>Your Notes</h2>

<?php
// Database connection code here
$conn = new mysqli('localhost', 'root', '', 'taskify');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve and display existing entries
$sql = "SELECT note_id, subject, title, content, file_url, url FROM notes"; // Include 'note_id' in the SELECT statement
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $note_id = $row['note_id']; // Store the 'note_id'
        $subject = $row['subject'];
        $title = $row['title'];
        $content = $row['content'];
        $file_url = $row['file_url'];
        $url = $row['url'];

        echo "<li>";
        echo "<strong>Subject:</strong> $subject<br>";
        echo "<strong>Note Title:</strong> $title<br>";
        echo "<p>$content</p>";

        // Display file if available
        if (!empty($file_url)) {
            echo "<a href='$file_url' target='_blank'>View File</a>";
        }

        // Display URL if available
        if (!empty($url)) {
            echo "<a href='$url' target='_blank'>Visit URL</a>";
        }

        // Add a delete button for each entry
        echo "<form action='delete_note.php' method='post'>";
        echo "<input type='hidden' name='note_id' value='$note_id'>"; // Use the actual 'note_id' value
        echo "<input type='submit' value='Delete'>";
        echo "</form>";

        echo "</li>";
    }
} else {
    echo "No entries found.";
}

$conn->close();
?>

</body>
</html>
