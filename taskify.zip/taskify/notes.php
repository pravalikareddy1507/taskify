<!DOCTYPE html>
<html>
<head>
    <title>Notes Organizer</title>
    <link rel="stylesheet"  type="text/css" href="notes.css">
</head>
<body>
    <h1>organise your notes here..</h1>
    <form action="#" method="post" enctype="multipart/form-data">
    <!-- Subject selection -->
    <div class="form-group">
    <label for="subject">Enter Subject:</label>
<input type="text" id="subject" name="subject" required>
</div> 
    <!-- Note input form -->
    <div class="form-group">
        <label for="title">Note Title:</label>
        <input type="text" id="title" name="title" required><br>
        </div> 
        <div class="form-group">
        <label for="content">Note Content:</label>
        <textarea id="content" name="content" rows="4" required></textarea><br>
        </div> 
        <div class="form-group">
        <label for="file">Attach File (Image/PDF):</label>
        <input type="file" id="file_url" name="file_url"><br>
        </div> 
        <div class="form-group">
        <label for="url">Add URL:</label>
        <input type="url" id="url" name="url" placeholder="http://www.example.com/index.html "><br>
        </div> 
        
        <div class="button-container" style="display: flex;">
        <button type="submit" id="note" name="note" >add note</button>
        
    <div>
        <button type="submit" id="c" name="c" >click here to view saved entry</button>
        <script>document.getElementById("c").addEventListener("click", function() {
    window.location.href = "ns.php";
});
</script>
        </div>
</div>
</form> 
         

    <!-- Display existing notes -->
    <?php
// Database connection code here
$conn = new mysqli('localhost', 'root', '', 'taskify');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

if(isset($_POST['note'])) {
    // Get form data
    $subject = $_POST['subject'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $file_url = $_FILES['file_url']['name'];
 // Handle file uploads and store the file URL
    $url = $_POST['url'];
    
    

    // Insert the data into the 'notes' table
    $sql = "INSERT INTO notes (subject, title, content, file_url, url) VALUES ('$subject', '$title', '$content', '$file_url', '$url')";

    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("notes added successfully");</script>';
    } else {
        echo 'Error: ' . $sql . '<br>' . $conn->error;
    }
}

$conn->close();
?>

</body>
</html>
